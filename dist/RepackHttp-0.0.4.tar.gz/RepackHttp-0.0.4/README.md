# Description
对请求方式进行重包装，便于日后更改模块功能